"""
Kalshi Tennis Trading Bot — Azure Function (Python v2)
Timer Trigger: every 30 minutes (0 */30 * * * *)

Strategy:
  1. Scan Tennis markets for matches starting within 30 min
  2. If yes_ask >= 65¢ and not already tracked → place 1-share Buy Limit at 45¢
  3. On each run check fills — if 45¢ buy filled → place 99¢ Sell Limit
  4. Auto-cleanup: cancel stale 45¢ orders if match_start + 60 min has passed
"""

import os
import json
import time
import logging
import base64
import hashlib
from datetime import datetime, timezone, timedelta

import azure.functions as func
import requests
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from azure.storage.blob import BlobServiceClient, ContainerClient

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
KALSHI_BASE = "https://api.elections.kalshi.com"
BLOB_CONTAINER = "tennis-bot-state"
BLOB_NAME = "validated_targets.json"
BUY_PRICE_CENTS = 45       # maker buy limit
SELL_PRICE_CENTS = 99       # taker sell limit
MIN_YES_ASK_CENTS = 65      # minimum yes_ask to target
SCAN_WINDOW_MINUTES = 30    # match must start within this window
STALE_MINUTES = 60          # cancel orders after this many minutes past match start

app = func.FunctionApp()

# ---------------------------------------------------------------------------
# RSA-PSS Signing (Kalshi v2 auth)
# ---------------------------------------------------------------------------

def _load_private_key():
    """Load the RSA private key from the KALSHI_PRIVATE_KEY_PEM env var with super-robust cleaning."""
    pem_data = os.environ["KALSHI_PRIVATE_KEY_PEM"]
    
    # 1. Clean basic noise
    pem_data = pem_data.replace('\\n', '\n').replace('"', '').strip()

    # 2. Handle 'One-Line' corruption (missing newlines after headers)
    header = "-----BEGIN RSA PRIVATE KEY-----"
    footer = "-----END RSA PRIVATE KEY-----"
    
    if header in pem_data and "\n" not in pem_data[len(header):len(header)+10]:
        # If there's no newline shortly after the header, it's likely collapsed
        content = pem_data.replace(header, "").replace(footer, "").strip()
        # Restore with proper newlines
        pem_data = f"{header}\n{content}\n{footer}"
    elif header not in pem_data and "MIIE" in pem_data:
        # If headers are missing entirely but it looks like base64
        pem_data = f"{header}\n{pem_data}\n{footer}"

    try:
        return serialization.load_pem_private_key(pem_data.encode(), password=None)
    except Exception as e:
        logging.error("Failed to load private key. PEM starting with: %s", pem_data[:50])
        raise e


def sign_request(method: str, path: str) -> dict:
    """
    Build Kalshi v2 auth headers.

    Message = timestamp_ms + method + path  (path WITHOUT query params)
    Signature = RSA-PSS(SHA-256) → base64
    """
    # Strip query string from path
    clean_path = path.split("?")[0]

    timestamp_ms = str(int(datetime.now(timezone.utc).timestamp() * 1000))
    message = (timestamp_ms + method.upper() + clean_path).encode()

    private_key = _load_private_key()
    logging.info("Signing message: [%s]", message.decode())
    
    signature = private_key.sign(
        message,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH,
        ),
        hashes.SHA256(),
    )

    # Key ID cleanup
    key_id = os.environ["KALSHI_API_KEY_ID"].replace('"', "").strip()
    logging.info("Using Key ID: %s...%s", key_id[:5], key_id[-5:])

    return {
        "KALSHI-ACCESS-KEY": key_id,
        "KALSHI-ACCESS-SIGNATURE": base64.b64encode(signature).decode(),
        "KALSHI-ACCESS-TIMESTAMP": timestamp_ms,
        "Content-Type": "application/json",
    }


def kalshi_get(path: str, params: dict | None = None) -> dict:
    """Authenticated GET to Kalshi v2 API with rate-limit sleep."""
    url = KALSHI_BASE + path
    headers = sign_request("GET", path)
    time.sleep(0.5)
    resp = requests.get(url, headers=headers, params=params, timeout=30)
    resp.raise_for_status()
    return resp.json()


def kalshi_post(path: str, body: dict) -> dict:
    """Authenticated POST to Kalshi v2 API with rate-limit sleep."""
    url = KALSHI_BASE + path
    headers = sign_request("POST", path)
    time.sleep(0.5)
    resp = requests.post(url, headers=headers, json=body, timeout=30)
    resp.raise_for_status()
    return resp.json()


def kalshi_delete(path: str) -> dict | None:
    """Authenticated DELETE to Kalshi v2 API with rate-limit sleep."""
    url = KALSHI_BASE + path
    headers = sign_request("DELETE", path)
    time.sleep(0.5)
    resp = requests.delete(url, headers=headers, timeout=30)
    resp.raise_for_status()
    if resp.content:
        return resp.json()
    return None


# ---------------------------------------------------------------------------
# Azure Blob Storage — State Management
# ---------------------------------------------------------------------------

def _get_container_client() -> ContainerClient:
    conn_str = os.environ["AZURE_STORAGE_CONNECTION_STRING"]
    blob_service = BlobServiceClient.from_connection_string(conn_str)
    container = blob_service.get_container_client(BLOB_CONTAINER)
    if not container.exists():
        container.create_container()
        logging.info("Created blob container: %s", BLOB_CONTAINER)
    return container


def load_state() -> dict:
    """Load state from blob storage. Returns empty dict if blob doesn't exist."""
    try:
        container = _get_container_client()
        blob = container.get_blob_client(BLOB_NAME)
        data = blob.download_blob().readall()
        state = json.loads(data)
        logging.info("Loaded state with %d tracked tickers", len(state))
        return state
    except Exception as exc:
        if "BlobNotFound" in str(exc) or "ResourceNotFound" in str(exc):
            logging.info("No existing state file — starting fresh")
            return {}
        raise


def save_state(state: dict) -> None:
    """Persist state dict to blob storage."""
    container = _get_container_client()
    blob = container.get_blob_client(BLOB_NAME)
    blob.upload_blob(json.dumps(state, indent=2), overwrite=True)
    logging.info("Saved state with %d tracked tickers", len(state))


# ---------------------------------------------------------------------------
# Market Scanning
# ---------------------------------------------------------------------------

def fetch_tennis_markets() -> list[dict]:
    """
    Fetch Tennis markets from Kalshi by targeting known tennis series tickers directly.
    Falls back to a capped full scan if targeted fetch returns nothing.
    """
    now = datetime.now(timezone.utc)
    window_end = now + timedelta(minutes=SCAN_WINDOW_MINUTES)

    # Known Kalshi tennis series tickers (ATP/WTA use KXATPMATCH, KXWTAMATCH etc.)
    TENNIS_SERIES_PREFIXES = ("KXATPMATCH", "KXWTAMATCH", "KXATPCHALLENGERMATCH", "KXWTACHALLENGERMATCH", "KXATP", "KXWTA", "TENNIS")

    def is_tennis(m: dict) -> bool:
        series = m.get("series_ticker", "").upper()
        event = m.get("event_ticker", "").upper()
        return any(series.startswith(p) or p in series or p in event for p in TENNIS_SERIES_PREFIXES)

    def filter_tennis(markets: list[dict]) -> list[dict]:
        """Filter markets to open, unresolved tennis markets within the time window."""
        results = []
        for m in markets:
            if not is_tennis(m):
                continue
            if m.get("result"):
                continue
            close_time_str = m.get("close_time") or m.get("expected_expiration_time")
            if close_time_str:
                try:
                    close_time = datetime.fromisoformat(close_time_str.replace("Z", "+00:00"))
                    if close_time < now or close_time > window_end:
                        continue
                except (ValueError, AttributeError):
                    pass
            results.append(m)
        return results

    def filter_tennis_in_window(markets: list[dict]) -> list[dict]:
        """Return open tennis markets for today's (or yesterday's) matchday.
        Kalshi close_time = tournament end date (useless for filtering).
        Instead filter by the YYMMMDD date embedded in the ticker, e.g. 26FEB23."""
        valid_dates = {
            (now - timedelta(days=d)).strftime("%y%b%d").upper()
            for d in range(2)  # today and yesterday UTC
        }
        return [
            m for m in markets
            if is_tennis(m)
            and not m.get("result")
            and any(d in m.get("ticker", "").upper() for d in valid_dates)
        ]


    all_tennis = []

    # Step 1: Try known tennis series tickers directly (fast path)
    known_tennis_series = ["KXATPMATCH", "KXWTAMATCH", "KXATPCHALLENGERMATCH", "KXWTACHALLENGERMATCH", "KXATP", "KXWTA", "KXMTENNIS", "TENNIS"]
    for series in known_tennis_series:
        try:
            cursor = None
            while True:
                params = {"limit": 200, "status": "open", "series_ticker": series}
                if cursor:
                    params["cursor"] = cursor
                data = kalshi_get("/trade-api/v2/markets", params=params)
                markets = data.get("markets", [])
                all_tennis.extend(filter_tennis_in_window(markets))
                cursor = data.get("cursor")
                if not cursor or not markets:
                    break
        except Exception as exc:
            logging.warning("series_ticker=%s fetch failed: %s", series, exc)

    if all_tennis:
        logging.info("Targeted tennis fetch: %d targets in window", len(all_tennis))
        return all_tennis

    # Step 2: Fallback — capped full scan (max 10 pages = 2000 markets)
    logging.warning("Targeted fetch returned 0 — falling back to capped full scan (max 10 pages)")
    all_markets = []
    cursor = None
    for page_num in range(10):
        params = {"limit": 200, "status": "open"}
        if cursor:
            params["cursor"] = cursor
        try:
            data = kalshi_get("/trade-api/v2/markets", params=params)
        except Exception as exc:
            logging.error("Full scan page %d failed: %s", page_num, exc)
            break
        markets = data.get("markets", [])
        all_markets.extend(markets)
        cursor = data.get("cursor")
        if not cursor or not markets:
            break

    tennis_targets = filter_tennis(all_markets)
    logging.info(
        "Fallback scan: %d total markets, %d tennis targets in window",
        len(all_markets), len(tennis_targets),
    )
    return tennis_targets




# ---------------------------------------------------------------------------
# Order Helpers
# ---------------------------------------------------------------------------

def get_portfolio_orders(ticker: str) -> list[dict]:
    """Get all open orders for a specific ticker."""
    data = kalshi_get(
        "/trade-api/v2/portfolio/orders",
        params={"ticker": ticker, "status": "resting"},
    )
    return data.get("orders", [])


def get_fills(ticker: str | None = None) -> list[dict]:
    """Get recent fills, optionally filtered by ticker."""
    params = {"limit": 100}
    if ticker:
        params["ticker"] = ticker
    data = kalshi_get("/trade-api/v2/portfolio/fills", params=params)
    return data.get("fills", [])


def place_buy_order(ticker: str, price_cents: int) -> str | None:
    """
    Place a 1-share Buy Limit Order (maker).
    Returns the order_id as a string, or None on failure.
    """
    body = {
        "ticker": ticker,
        "action": "buy",
        "side": "yes",
        "type": "limit",
        "count": 1,
        "yes_price": price_cents,
        "client_order_id": f"TENNIS-BUY-{int(time.time())}"
    }
    try:
        resp = kalshi_post("/trade-api/v2/portfolio/orders", body)
        order = resp.get("order", {})
        order_id = str(order.get("order_id", ""))
        logging.info(
            "BUY ORDER PLACED — ticker: %s, price: %d¢, order_id: %s",
            ticker,
            price_cents,
            order_id,
        )
        return order_id
    except requests.HTTPError as exc:
        logging.error("Failed to place buy order for %s: %s", ticker, exc)
        return None


def place_sell_order(ticker: str, price_cents: int) -> str | None:
    """
    Place a 1-share Sell Limit Order (taker).
    Returns the order_id as a string, or None on failure.
    """
    body = {
        "ticker": ticker,
        "action": "sell",
        "side": "yes",
        "type": "limit",
        "count": 1,
        "yes_price": price_cents,
        "client_order_id": f"TENNIS-SELL-{int(time.time())}"
    }
    try:
        resp = kalshi_post("/trade-api/v2/portfolio/orders", body)
        order = resp.get("order", {})
        order_id = str(order.get("order_id", ""))
        logging.info(
            "SELL ORDER PLACED — ticker: %s, price: %d¢, order_id: %s",
            ticker,
            price_cents,
            order_id,
        )
        return order_id
    except requests.HTTPError as exc:
        logging.error("Failed to place sell order for %s: %s", ticker, exc)
        return None


def cancel_order(order_id: str) -> bool:
    """Cancel a resting order by its ID."""
    try:
        kalshi_delete(f"/trade-api/v2/portfolio/orders/{order_id}")
        logging.info("ORDER CANCELLED — order_id: %s", order_id)
        return True
    except requests.HTTPError as exc:
        logging.error("Failed to cancel order %s: %s", order_id, exc)
        return False


# ---------------------------------------------------------------------------
# Core Bot Logic
# ---------------------------------------------------------------------------

def scan_and_target(state: dict) -> dict:
    """Step 1: Scan markets and place buy orders on new targets.

    For each match, Kalshi has separate tickers for each side (e.g. LAJBER-LAJ
    and LAJBER-BER). Since only one side can win, we group tickers by their
    base match ID and only buy the side with the highest yes_ask (the favorite).
    This prevents bidding on both sides of the same match.
    """
    markets = fetch_tennis_markets()

    # Group qualifying markets by base match ID (ticker minus the trailing player code)
    # e.g. "KXATPMATCH-26FEB22LAJBER-LAJ" → base = "KXATPMATCH-26FEB22LAJBER"
    match_candidates: dict[str, dict] = {}  # base_id → best market so far

    for m in markets:
        ticker = m["ticker"]
        yes_ask = m.get("yes_ask")

        if yes_ask is None:
            continue
        if yes_ask < MIN_YES_ASK_CENTS:
            continue
        if ticker in state:
            logging.info("Ticker %s already tracked — skipping", ticker)
            continue

        # Derive base match ID by stripping the last dash-separated segment
        parts = ticker.rsplit("-", 1)
        base_id = parts[0] if len(parts) == 2 else ticker

        # Keep only the highest yes_ask side per match
        existing = match_candidates.get(base_id)
        if existing is None or yes_ask > existing.get("yes_ask", 0):
            match_candidates[base_id] = m

    # Place buy orders only on the winning (highest yes_ask) side per match
    for base_id, m in match_candidates.items():
        ticker = m["ticker"]
        yes_ask = m["yes_ask"]

        logging.info(
            "TARGET FOUND — ticker: %s, yes_ask: %d¢ (best side for match %s)",
            ticker,
            yes_ask,
            base_id,
        )

        close_time_str = m.get("close_time") or m.get("expected_expiration_time", "")
        order_id = place_buy_order(ticker, BUY_PRICE_CENTS)
        if order_id:
            state[ticker] = {
                "order_id": order_id,
                "match_start": close_time_str,
                "status": "pending_buy",
            }

    return state


def check_fills_and_sell(state: dict) -> dict:
    """Step 2: Check if any pending buy orders have been filled, then place sells.
    Uses a single bulk fills fetch to avoid N individual API calls.
    """
    pending_buys = {
        ticker: info
        for ticker, info in state.items()
        if info.get("status") == "pending_buy"
    }

    if not pending_buys:
        logging.info("No pending buy orders to check for fills")
        return state

    # Single bulk fetch — check last 200 fills across all tickers
    try:
        all_fills = get_fills()  # no ticker filter
    except Exception as exc:
        logging.error("Failed to fetch fills: %s", exc)
        return state

    # Build set of filled order IDs for O(1) lookup
    filled_order_ids = {
        f.get("order_id")
        for f in all_fills
        if f.get("action") == "buy"
    }

    for ticker, info in pending_buys.items():
        if info["order_id"] not in filled_order_ids:
            continue

        logging.info(
            "FILL DETECTED — ticker: %s, buy order_id: %s",
            ticker,
            str(info["order_id"]),
        )

        # Check for existing sell orders to prevent duplicates
        existing_orders = get_portfolio_orders(ticker)
        has_sell = any(
            o.get("action") == "sell"
            and o.get("yes_price") == SELL_PRICE_CENTS
            for o in existing_orders
        )

        if has_sell:
            logging.info(
                "Sell order already exists for %s at %d¢ — skipping duplicate",
                ticker,
                SELL_PRICE_CENTS,
            )
            state[ticker]["status"] = "pending_sell"
            continue

        sell_order_id = place_sell_order(ticker, SELL_PRICE_CENTS)
        if sell_order_id:
            state[ticker]["status"] = "pending_sell"
            state[ticker]["sell_order_id"] = sell_order_id

    return state


def auto_cleanup(state: dict) -> dict:
    """Step 3: Cancel stale pending_buy orders past the match window."""
    now = datetime.now(timezone.utc)
    tickers_to_remove = []

    for ticker, info in state.items():
        if info.get("status") != "pending_buy":
            continue

        match_start_str = info.get("match_start", "")
        if not match_start_str:
            continue

        try:
            match_start = datetime.fromisoformat(
                match_start_str.replace("Z", "+00:00")
            )
        except (ValueError, AttributeError):
            continue

        deadline = match_start + timedelta(minutes=STALE_MINUTES)
        if now > deadline:
            logging.info(
                "STALE ORDER — ticker: %s, match_start: %s, cancelling order_id: %s",
                ticker,
                match_start_str,
                str(info["order_id"]),
            )
            cancelled = cancel_order(str(info["order_id"]))
            if cancelled:
                tickers_to_remove.append(ticker)

    for ticker in tickers_to_remove:
        del state[ticker]
        logging.info("Removed stale ticker from state: %s", ticker)

    return state


def check_settled_markets(state: dict) -> dict:
    """Step 4: Clean up any settled markets from state."""
    tickers_to_remove = []

    for ticker, info in list(state.items()):
        if info.get("status") not in ("pending_sell",):
            continue

        # Check if market has settled by looking at fills for sell-side
        fills = get_fills(ticker=ticker)
        sell_filled = any(
            f.get("action") == "sell"
            for f in fills
        )

        if sell_filled:
            logging.info(
                "SELL FILLED / SETTLED — ticker: %s, removing from state",
                ticker,
            )
            tickers_to_remove.append(ticker)

    for ticker in tickers_to_remove:
        del state[ticker]

    return state


# ---------------------------------------------------------------------------
# Timer Trigger (every 30 minutes)
# ---------------------------------------------------------------------------

@app.timer_trigger(
    schedule="0 */30 * * * *",
    arg_name="timer",
    run_on_startup=False,
)
def tennis_bot(timer: func.TimerRequest) -> None:
    """Main entry point — runs every 30 minutes."""
    logging.info("=" * 60)
    logging.info("TENNIS BOT RUN STARTED at %s", datetime.now(timezone.utc).isoformat())
    logging.info("=" * 60)

    if timer.past_due:
        logging.warning("Timer is past due — running anyway")

    try:
        # Load persisted state
        state = load_state()

        # Step 1: Scan markets and place new buy orders
        state = scan_and_target(state)

        # Step 2: Check fills and place sell orders
        state = check_fills_and_sell(state)

        # Step 3: Auto-cleanup stale orders
        state = auto_cleanup(state)

        # Step 4: Clean up settled markets
        state = check_settled_markets(state)

        # Persist updated state
        save_state(state)

        logging.info("TENNIS BOT RUN COMPLETED — %d tickers tracked", len(state))

    except Exception:
        logging.exception("TENNIS BOT RUN FAILED")
        raise
