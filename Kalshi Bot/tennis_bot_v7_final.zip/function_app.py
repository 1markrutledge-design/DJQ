"""
V2.14 Strategy:
  1. Sync actual Kalshi portfolio to internal state (Precision Exit discovery)
     - SAFETY: Filter for Tennis tickers only (KXATP/KXWTA).
  2. Scan Tennis markets for matches starting within 90 min (Today Only)
  3. Filter: 63c Mean Price Floor, 55c Bid Floor, 98c Ask Ceiling
  4. Entry: Place 7-share Buy Limit at (Mean Price - 10c), capped at 78c
  5. Monitoring: If 10c-discount buy filled -> Place Sell Limit at 85c (matches exact share count)
  6. Drawdown Recovery: If bid drops to 30c or below -> Hard Stop Loss (Market Exit override)
  7. Zombie Cleanup: Automatically remove markets with status 'finalized' or 'settled'.

### 1. Tennis Bot (V2.16 / Robust Stop Loss & Audit)
*   **Bid Buffer**: 3-count buffer for "Empty Book" exits to prevent 1¢ panic-selling.
*   **Account-Aware Audit**: Standardizes all tennis sells to 85¢ and matches them to actual shares.
*   **Unique Identity**: Unique client_order_ids (ticker + ms) to prevent 409 Conflicts.
*   **7-Share Scaling**: Increased position (standard target is 7 shares).
"""

import os
import json
import time
import logging
import base64
import hashlib
from datetime import datetime, timezone, timedelta

import azure.functions as func
import requests
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from azure.storage.blob import BlobServiceClient, ContainerClient

# ---------------------------------------------------------------------------
# Configuration (Tennis Bot V2.13 — Drawdown Recovery)
# ---------------------------------------------------------------------------
KALSHI_BASE = "https://api.elections.kalshi.com"
BLOB_CONTAINER = "tennis-bot-state"
BLOB_NAME = "validated_targets.json"
MATCH_CACHE_BLOB = "match_cache.json"

# Entry Filters (More restrictive to avoid "falling knives")
MIN_YES_BID = 55            # Match must have a decent floor
MAX_YES_ASK = 98            # Avoid already settled or near-settled
MIN_MEAN_PRICE = 63         # Ensure we are betting on a clear favorite

# Capital Preservation
STOP_LOSS_PRICE = 30        # Exit immediately if favorability tanks
TARGET_EXIT_PRICE = 85      # Take profit target
MAX_ENTRY_PRICE = 78        # V2.9: Hard cap to ensure profit margin
BUY_PRICE_CENTS = 45        # Fallback if dynamic pricing fails

SCAN_WINDOW_MINUTES = 90    # match must start within this window
STALE_MINUTES = 60          # cancel orders after this many minutes past match start

app = func.FunctionApp()

# ---------------------------------------------------------------------------
# RSA-PSS Signing (Kalshi v2 auth)
# ---------------------------------------------------------------------------

def _load_private_key():
    """Load the RSA private key from the KALSHI_PRIVATE_KEY_PEM env var with super-robust cleaning."""
    pem_data = os.environ["KALSHI_PRIVATE_KEY_PEM"]
    
    # 1. Clean basic noise
    pem_data = pem_data.replace('\\n', '\n').replace('"', '').strip()

    # 2. Handle 'One-Line' corruption (missing newlines after headers)
    header = "-----BEGIN RSA PRIVATE KEY-----"
    footer = "-----END RSA PRIVATE KEY-----"
    
    if header in pem_data and "\n" not in pem_data[len(header):len(header)+10]:
        # If there's no newline shortly after the header, it's likely collapsed
        content = pem_data.replace(header, "").replace(footer, "").strip()
        # Restore with proper newlines
        pem_data = f"{header}\n{content}\n{footer}"
    elif header not in pem_data and "MIIE" in pem_data:
        # If headers are missing entirely but it looks like base64
        pem_data = f"{header}\n{pem_data}\n{footer}"

    try:
        return serialization.load_pem_private_key(pem_data.encode(), password=None)
    except Exception as e:
        logging.error("Failed to load private key. PEM starting with: %s", pem_data[:50])
        raise e


def sign_request(method: str, path: str) -> dict:
    """
    Build Kalshi v2 auth headers.

    Message = timestamp_ms + method + path  (path WITHOUT query params)
    Signature = RSA-PSS(SHA-256) → base64
    """
    # Strip query string from path
    clean_path = path.split("?")[0]

    timestamp_ms = str(int(datetime.now(timezone.utc).timestamp() * 1000))
    message = (timestamp_ms + method.upper() + clean_path).encode()

    private_key = _load_private_key()
    logging.info("Signing message: [%s]", message.decode())
    
    signature = private_key.sign(
        message,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH,
        ),
        hashes.SHA256(),
    )

    # Key ID cleanup
    key_id = os.environ["KALSHI_API_KEY_ID"].replace('"', "").strip()
    logging.info("Using Key ID: %s...%s", key_id[:5], key_id[-5:])

    return {
        "KALSHI-ACCESS-KEY": key_id,
        "KALSHI-ACCESS-SIGNATURE": base64.b64encode(signature).decode(),
        "KALSHI-ACCESS-TIMESTAMP": timestamp_ms,
        "Content-Type": "application/json",
    }


def kalshi_get(path: str, params: dict | None = None) -> dict:
    """Authenticated GET to Kalshi v2 API with rate-limit sleep."""
    url = KALSHI_BASE + path
    headers = sign_request("GET", path)
    time.sleep(0.5)
    resp = requests.get(url, headers=headers, params=params, timeout=30)
    resp.raise_for_status()
    return resp.json()


def kalshi_post(path: str, body: dict) -> dict:
    """Authenticated POST to Kalshi v2 API with rate-limit sleep."""
    url = KALSHI_BASE + path
    headers = sign_request("POST", path)
    time.sleep(0.5)
    resp = requests.post(url, headers=headers, json=body, timeout=30)
    resp.raise_for_status()
    return resp.json()


def kalshi_delete(path: str) -> dict | None:
    """Authenticated DELETE to Kalshi v2 API with rate-limit sleep."""
    url = KALSHI_BASE + path
    headers = sign_request("DELETE", path)
    time.sleep(0.5)
    resp = requests.delete(url, headers=headers, timeout=30)
    resp.raise_for_status()
    if resp.content:
        return resp.json()
    return None


# ---------------------------------------------------------------------------
# Azure Blob Storage — State Management
# ---------------------------------------------------------------------------

def _get_container_client() -> ContainerClient:
    conn_str = os.environ["AZURE_STORAGE_CONNECTION_STRING"]
    blob_service = BlobServiceClient.from_connection_string(conn_str)
    container = blob_service.get_container_client(BLOB_CONTAINER)
    if not container.exists():
        container.create_container()
        logging.info("Created blob container: %s", BLOB_CONTAINER)
    return container


def load_state() -> dict:
    """Load state from blob storage. Returns empty dict if blob doesn't exist."""
    try:
        container = _get_container_client()
        blob = container.get_blob_client(BLOB_NAME)
        data = blob.download_blob().readall()
        state = json.loads(data)
        logging.info("Loaded state with %d tracked tickers", len(state))
        return state
    except Exception as exc:
        if "BlobNotFound" in str(exc) or "ResourceNotFound" in str(exc):
            logging.info("No existing state file — starting fresh")
            return {}
        raise


def save_state(state: dict) -> None:
    """Persist state dict to blob storage."""
    container = _get_container_client()
    blob = container.get_blob_client(BLOB_NAME)
    blob.upload_blob(json.dumps(state, indent=2), overwrite=True)
    logging.info("Saved state with %d tracked tickers", len(state))


def load_match_cache() -> dict:
    """Load Ground-Truth match times from blob storage."""
    try:
        container = _get_container_client()
        blob = container.get_blob_client(MATCH_CACHE_BLOB)
        data = blob.download_blob().readall()
        cache = json.loads(data)
        logging.info("Loaded match cache with %d entries", len(cache.get("matches", [])))
        return cache
    except Exception as exc:
        logging.info("No match cache found or failed to load: %s", exc)
        return {"matches": []}


# ---------------------------------------------------------------------------
# Market Scanning
# ---------------------------------------------------------------------------

def fetch_tennis_markets() -> list[dict]:
    """
    Fetch Tennis markets from Kalshi by targeting known tennis series tickers directly.
    Falls back to a capped full scan if targeted fetch returns nothing.
    """
    now = datetime.now(timezone.utc)
    window_end = now + timedelta(minutes=SCAN_WINDOW_MINUTES)

    # Known Kalshi tennis series tickers (ATP/WTA use KXATPMATCH, KXWTAMATCH etc.)
    TENNIS_SERIES_PREFIXES = ("KXATPMATCH", "KXWTAMATCH", "KXATPCHALLENGERMATCH", "KXWTACHALLENGERMATCH", "KXATP", "KXWTA", "TENNIS")

    def is_tennis(m: dict) -> bool:
        series = m.get("series_ticker", "").upper()
        event = m.get("event_ticker", "").upper()
        return any(series.startswith(p) or p in series or p in event for p in TENNIS_SERIES_PREFIXES)

    def filter_tennis(markets: list[dict]) -> list[dict]:
        """Filter markets to open, unresolved tennis markets within the time window."""
        results = []
        for m in markets:
            if not is_tennis(m):
                continue
            if m.get("result"):
                continue
            close_time_str = m.get("close_time") or m.get("expected_expiration_time")
            if close_time_str:
                try:
                    close_time = datetime.fromisoformat(close_time_str.replace("Z", "+00:00"))
                    if close_time < now:
                        continue
                except (ValueError, AttributeError):
                    pass
            results.append(m)
        return results

    def filter_tennis_in_window(markets: list[dict]) -> list[dict]:
        """Return open tennis markets for today's (or yesterday's) matchday.
        Kalshi close_time = tournament end date (useless for filtering).
        Instead filter by the YYMMMDD date embedded in the ticker, e.g. 26FEB23."""
        valid_dates = {
            (now - timedelta(days=d)).strftime("%y%b%d").upper()
            for d in range(1)  # today UTC only
        }
        return [
            m for m in markets
            if is_tennis(m)
            and not m.get("result")
            and any(d in m.get("ticker", "").upper() for d in valid_dates)
        ]


    all_tennis_map = {}

    def add_to_results(markets: list[dict]):
        for m in markets:
            ticker = m.get("ticker")
            if ticker and ticker not in all_tennis_map:
                all_tennis_map[ticker] = m

    # Step 1: Targeted fetch for known high-priority series (fast path)
    known_tennis_series = ["KXATPMATCH", "KXWTAMATCH", "KXATPCHALLENGERMATCH", "KXWTACHALLENGERMATCH", "KXATP", "KXWTA", "KXMTENNIS", "TENNIS"]
    for series in known_tennis_series:
        try:
            cursor = None
            while True:
                params = {"limit": 200, "status": "open", "series_ticker": series}
                if cursor: params["cursor"] = cursor
                data = kalshi_get("/trade-api/v2/markets", params=params)
                markets = data.get("markets", [])
                add_to_results(filter_tennis_in_window(markets))
                cursor = data.get("cursor")
                if not cursor or not markets: break
        except Exception as exc:
            logging.warning("series_ticker=%s fetch failed: %s", series, exc)

    # Step 2: Broad scan (Ensures we catch matches with NO series ticker assigned)
    logging.info("Performing broad scan to ensure no missing targets (like Alcaraz)...")
    cursor = None
    for page_num in range(12): # Scan up to 2400 markets
        try:
            params = {"limit": 200, "status": "open"}
            if cursor: params["cursor"] = cursor
            data = kalshi_get("/trade-api/v2/markets", params=params)
            markets = data.get("markets", [])
            add_to_results(filter_tennis(markets))
            cursor = data.get("cursor")
            if not cursor or not markets: break
        except Exception as exc:
            logging.error("Broad scan page %d failed: %s", page_num, exc)
            break

    final_targets = list(all_tennis_map.values())
    logging.info("TENNIS DISCOVERY COMPLETE: Found %d unique targets.", len(final_targets))
    return final_targets


def get_market_pulse(ticker: str) -> dict:
    """Fetch the absolute latest orderbook for a specific ticker (Deep Pulse)."""
    try:
        data = kalshi_get(f"/trade-api/v2/markets/{ticker}")
        return data.get("market", {})
    except Exception as exc:
        logging.error("Pulse Failed for %s: %s", ticker, exc)
        return {}




# ---------------------------------------------------------------------------
# Order Helpers
# ---------------------------------------------------------------------------

def get_portfolio_orders(ticker: str) -> list[dict]:
    """Get all open orders for a specific ticker."""
    data = kalshi_get(
        "/trade-api/v2/portfolio/orders",
        params={"ticker": ticker, "status": "resting"},
    )
    return data.get("orders", [])


def get_fills(ticker: str | None = None) -> list[dict]:
    """Get recent fills, optionally filtered by ticker."""
    params = {"limit": 100}
    if ticker:
        params["ticker"] = ticker
    data = kalshi_get("/trade-api/v2/portfolio/fills", params=params)
    return data.get("fills", [])


def place_buy_order(ticker: str, price_cents: int, count: int = 7) -> str | None:
    """
    Place a Buy Limit Order (maker).
    Returns the order_id as a string, or None on failure.
    """
    # MAKER PROTECTION: check current ask
    pulse = get_market_pulse(ticker)
    actual_ask = pulse.get("yes_ask")
    
    if actual_ask is not None:
        # sit 1 cent below the current ask to ensure maker status
        price_cents = min(price_cents, actual_ask - 1)
        if price_cents < 5: # safety floor
            logging.warning("Price too low for %s: %d", ticker, price_cents)
            return None

    body = {
        "ticker": ticker,
        "action": "buy",
        "side": "yes",
        "type": "limit",
        "count": count,
        "yes_price": price_cents,
        "client_order_id": f"T-BUY-{int(time.time()*1000)}-{ticker[-32:]}"
    }
    try:
        resp = kalshi_post("/trade-api/v2/portfolio/orders", body)
        order = resp.get("order", {})
        order_id = str(order.get("order_id", ""))
        logging.info(
            "BUY ORDER PLACED — ticker: %s, price: %d¢, order_id: %s",
            ticker,
            price_cents,
            order_id,
        )
        return order_id
    except requests.HTTPError as exc:
        logging.error("Failed to place buy order for %s: %s", ticker, exc)
        return None


def place_sell_order(ticker: str, price_cents: int, count: int = 7, is_emergency: bool = False) -> str | None:
    """
    Place a Sell Limit Order (taker).
    If is_emergency, allow prices below 5c to ensure exit.
    """
    # MAKER PROTECTION: check current bid
    pulse = get_market_pulse(ticker)
    actual_bid = pulse.get("yes_bid")
    
    if actual_bid is not None and not is_emergency:
        # sit 1 cent above the current bid to ensure maker status
        # but ONLY if we aren't panicking (emergency exit)
        if price_cents <= actual_bid:
            price_cents = actual_bid + 1
            logging.info("Forcing MAKER sell at %d¢ for %s", price_cents, ticker)

        if price_cents < 5: # safety floor for standard sells
            logging.warning("Price too low for %s: %d", ticker, price_cents)
            return None
    
    if is_emergency:
        # Override floor and price for immediate exit
        price_cents = max(1, price_cents) # floor at 1 cent for API
        logging.warning("EMERGENCY EXIT for %s at %d¢ (%d shares)", ticker, price_cents, count)

    body = {
        "ticker": ticker,
        "action": "sell",
        "side": "yes",
        "type": "limit",
        "count": count,
        "yes_price": price_cents,
        "client_order_id": f"T-SELL-{int(time.time()*1000)}-{ticker[-32:]}"
    }
    try:
        resp = kalshi_post("/trade-api/v2/portfolio/orders", body)
        order = resp.get("order", {})
        order_id = str(order.get("order_id", ""))
        logging.info(
            "SELL ORDER PLACED — ticker: %s, price: %d¢, count: %d, order_id: %s",
            ticker,
            price_cents,
            count,
            order_id,
        )
        return order_id
    except requests.HTTPError as exc:
        logging.error("Failed to place sell order for %s: %s", ticker, exc)
        return None


def cancel_order(order_id: str) -> bool:
    """Cancel a resting order by its ID."""
    try:
        kalshi_delete(f"/trade-api/v2/portfolio/orders/{order_id}")
        logging.info("ORDER CANCELLED — order_id: %s", order_id)
        return True
    except requests.HTTPError as exc:
        logging.error("Failed to cancel order %s: %s", order_id, exc)
        return False


# ---------------------------------------------------------------------------
# Core Bot Logic
# ---------------------------------------------------------------------------

def scan_and_target(state: dict) -> dict:
    """Step 1: Scan markets and place buy orders on new targets.
    V2.4: Simple Mean - 10¢ Pricing.
    """
    def get_portfolio_active_match_ids() -> set[str]:
        """Returns set of base_ids (e.g. KXATP...JOVPAR) for all active positions/resting orders."""
        active_ids = set()
        try:
            # 1. Active Positions
            resp = kalshi_get("/trade-api/v2/portfolio/positions")
            pos_list = resp if isinstance(resp, list) else resp.get("market_positions", [])
            for p in pos_list:
                if float(p.get("position_fp", 0)) != 0:
                    ticker = p.get("ticker", "")
                    # Extract base_id (remove -PLA/ -POS)
                    parts = ticker.rsplit("-", 1)
                    base_id = parts[0] if len(parts) == 2 else ticker
                    active_ids.add(base_id)
            
            # 2. Open Orders
            resp = kalshi_get("/trade-api/v2/portfolio/orders", params={"status": "resting"})
            ord_list = resp if isinstance(resp, list) else resp.get("orders", [])
            for o in ord_list:
                if o.get("action") == "buy":
                    ticker = o.get("ticker", "")
                    parts = ticker.rsplit("-", 1)
                    base_id = parts[0] if len(parts) == 2 else ticker
                    active_ids.add(base_id)
        except Exception as e:
            logging.error("Match ID check failed: %s", e)
        return active_ids

    markets = fetch_tennis_markets()
    now = datetime.now(timezone.utc)
    
    # NEW V2.9: Check by Match ID to prevent buying 'Both Sides'
    existing_match_ids = get_portfolio_active_match_ids()

    # Group by base match ID
    match_candidates: dict[str, dict] = {}
    for m in markets:
        ticker = m["ticker"]
        parts = ticker.rsplit("-", 1)
        base_id = parts[0] if len(parts) == 2 else ticker

        # Skip if already in local state OR if the match is already in portfolio
        if ticker in state or base_id in existing_match_ids: continue
        existing = match_candidates.get(base_id)
        if existing is None or (m.get("yes_ask") or 0) > (existing.get("yes_ask") or 0):
            match_candidates[base_id] = m

    for base_id, summary_m in match_candidates.items():
        ticker = summary_m["ticker"]
        
        # Timing check: Kalshi internal timing (within 60 mins of start)
        raw_start = summary_m.get("expected_price_start_time") or summary_m.get("open_time")
        if not raw_start: continue
        
        # Initialize match_start with the best available data
        is_real_start = bool(summary_m.get("expected_price_start_time"))
        try:
            match_start = datetime.fromisoformat(raw_start.replace("Z", "+00:00"))
        except Exception:
            # Fallback for weirdly formatted times
            match_start = now
            is_real_start = False

        # Timing check: Use expected_expiration_time as the ultimate cutoff
        expected_expiry_str = summary_m.get("expected_expiration_time") or summary_m.get("close_time")
        if expected_expiry_str:
            try:
                expiry_time = datetime.fromisoformat(expected_expiry_str.replace("Z", "+00:00"))
                # Skip if match has already reached its expected conclusion
                if now > (expiry_time + timedelta(minutes=15)):
                    continue
            except: pass

        # Filter: Don't bid if it starts too far in the future or is too deep into the game
        if is_real_start:
            minutes_to_start = (match_start - now).total_seconds() / 60
            if minutes_to_start > SCAN_WINDOW_MINUTES: continue
            # NEW (Option B): Stop entering new positions after 30 minutes in play
            if minutes_to_start < -30: continue 
        
        # Deep Pulse: Accuracy fallback - Ensure the market is still active and has valid prices
        
        # Deep Pulse: Accuracy fallback
        try:
            live_data = kalshi_get(f"/trade-api/v2/markets/{ticker}")
            m = live_data.get("market", {})
            
            # Handle both cent and dollar formats (Kalshi API inconsistency)
            yes_bid = m.get("yes_bid")
            if yes_bid is None and m.get("yes_bid_dollars") is not None:
                yes_bid = int(float(m["yes_bid_dollars"]) * 100)
                
            yes_ask = m.get("yes_ask")
            if yes_ask is None and m.get("yes_ask_dollars") is not None:
                yes_ask = int(float(m["yes_ask_dollars"]) * 100)
        except Exception: continue
            
        if yes_bid is None or yes_ask is None: continue

        # Filter and Execute (V2.4 Mean - 10¢)
        if yes_bid <= MIN_YES_BID or yes_ask >= MAX_YES_ASK: continue
        mean_price = (yes_bid + yes_ask) / 2.0
        if mean_price <= MIN_MEAN_PRICE: continue

        target_buy_price = int(mean_price - 10)
        # V2.9 Profit Protection: Clamp to MAX_ENTRY_PRICE
        target_buy_price = min(target_buy_price, MAX_ENTRY_PRICE)
        
        logging.info("V2.9 TARGET: %s at %d¢ (capped from mean %d¢)", ticker, target_buy_price, int(mean_price))

        order_id = place_buy_order(ticker, target_buy_price)
        if order_id:
            state[ticker] = {
                "order_id": order_id,
                "match_start": match_start.isoformat(),
                "is_real_start": is_real_start,
                "status": "pending_buy",
            }
    return state


def check_fills_and_sell(state: dict) -> dict:
    """Step 2: Detect fills and update state. The Audit logic handles placement.
    """
    pending_buys = {
        ticker: info
        for ticker, info in state.items()
        if info.get("status") == "pending_buy"
    }

    if not pending_buys:
        return state

    try:
        all_fills = get_fills()
    except Exception as exc:
        logging.error("Failed to fetch fills: %s", exc)
        return state

    filled_order_ids = {
        f.get("order_id")
        for f in all_fills
        if f.get("action") == "buy"
    }

    for ticker, info in pending_buys.items():
        if info["order_id"] in filled_order_ids:
            logging.info("FILL DETECTED — ticker: %s, updating state for Audit.", ticker)
            # Move to pending_sell to trigger the Take Profit Audit
            state[ticker]["status"] = "pending_sell"
            # Note: We don't set shares here; sync_portfolio (Next Run) will find them.
            
    return state


def auto_cleanup(state: dict) -> dict:
    """Step 3: Cancel stale buy orders that never filled."""
    now = datetime.now(timezone.utc)
    changed = False
    to_delete = []

    for ticker, info in state.items():
        if info.get("status") == "pending_buy":
            # Only use the 10-minute cleanup if we have a real match start time
            if info.get("is_real_start", True):
                match_start_str = info.get("match_start")
                if not match_start_str: continue
                try:
                    match_start = datetime.fromisoformat(match_start_str.replace("Z", "+00:00"))
                    if now > (match_start + timedelta(minutes=10)):
                        logging.info("STALE ORDER — ticker: %s, match_start: %s, cancelling order_id: %s", 
                                     ticker, match_start, info["order_id"])
                        try:
                            cancel_order(info["order_id"])
                            logging.info("ORDER CANCELLED — order_id: %s", info["order_id"])
                        except Exception as exc:
                            if "404" in str(exc):
                                logging.error("Already cancelled/filled: %s", info["order_id"])
                            else:
                                logging.error("Failed to cancel %s: %s", info["order_id"], exc)
                        to_delete.append(ticker)
                except Exception:
                    continue
    
    for ticker in to_delete:
        del state[ticker]
    return state


def check_settled_markets(state: dict) -> dict:
    """Step 4: Clean up any settled markets from state."""
    tickers_to_remove = []

    for ticker, info in list(state.items()):
        # Fetch current market status (Finalized/Settled Check)
        try:
            m_data = kalshi_get(f"/trade-api/v2/markets/{ticker}")
            market = m_data.get("market", {})
            status = market.get("status", "unknown")
            if status in ("finalized", "settled", "voided"):
                logging.info("ZOMBIE MARKET REMOVED — ticker: %s, status: %s", ticker, status)
                tickers_to_remove.append(ticker)
                continue
        except Exception: 
            pass # fallback to fill-based cleanup

        if info.get("status") not in ("pending_sell",):
            continue

        # Check if market has settled by looking at fills for sell-side
        fills = get_fills(ticker=ticker)
        sell_filled = any(
            f.get("action") == "sell"
            for f in fills
        )

        if sell_filled:
            logging.info(
                "SELL FILLED / SETTLED — ticker: %s, removing from state",
                ticker,
            )
            tickers_to_remove.append(ticker)

    for ticker in tickers_to_remove:
        del state[ticker]

    return state


def sync_portfolio_to_state(state: dict) -> dict:
    """
    V2.15 Account Audit:
    1. Fetches ALL positions and ALL resting orders.
    2. Updates state with actual shares owned.
    3. Corrects/Cancels mismatches between owned shares and sell count.
    """
    try:
        # Load reality from Kalshi
        logging.info("Step 0: Performing full Account-Aware Audit...")
        
        # 1. Fetch Positions
        resp_pos = kalshi_get("/trade-api/v2/portfolio/positions")
        pos_list = resp_pos if isinstance(resp_pos, list) else resp_pos.get("market_positions", [])
        
        # 2. Fetch ALL Resting Orders
        resp_ord = kalshi_get("/trade-api/v2/portfolio/orders", params={"status": "resting"})
        ord_list = resp_ord if isinstance(resp_ord, list) else resp_ord.get("orders", [])

        # Process Positions
        real_shares = {}
        for p in pos_list:
            ticker = p.get("ticker", "")
            if not ticker.startswith(("KXATP", "KXWTA")): continue
            real_shares[ticker] = int(float(p.get("position_fp", 0)))

        # Process Orders (Categorized by Ticker)
        resting_sells = {}
        for o in ord_list:
            ticker = o.get("ticker", "")
            if o.get("action") == "sell":
                if ticker not in resting_sells: resting_sells[ticker] = []
                resting_sells[ticker].append(o)

        # AUDIT Logic: Correct the bot's state and Kalshi's orders
        all_tracked_tickers = set(state.keys()) | set(real_shares.keys())
        
        for ticker in all_tracked_tickers:
            if not ticker.startswith(("KXATP", "KXWTA")): continue

            owned = real_shares.get(ticker, 0)
            sells = resting_sells.get(ticker, [])
            total_committed = sum(int(s.get("count", 0)) for s in sells)
            
            # Update state memory
            if owned > 0:
                if ticker not in state:
                    state[ticker] = {"status": "pending_sell", "shares": owned, "match_start": datetime.now(timezone.utc).isoformat(), "is_real_start": False}
                else:
                    state[ticker]["shares"] = owned
                    if state[ticker].get("status") == "pending_buy":
                        state[ticker]["status"] = "pending_sell" # Flip to sell monitoring

            # CORRECTIVE ACTION: Prevent Overselling or Price Drift
            if owned > 0:
                # If we own shares but have the WRONG sell count or WRONG price
                wrong_price = any(int(s.get("yes_price", 0)) != TARGET_EXIT_PRICE for s in sells)
                
                if total_committed != owned or wrong_price:
                    logging.info("⚖️ AUDIT CORRECTION: Ticker %s owns %d, but has %d committed at various prices. Resetting...", ticker, owned, total_committed)
                    # Kill them all and start over for this ticker
                    for s in sells:
                        cancel_order(str(s["order_id"]))
                    # Place fresh precision order
                    new_id = place_sell_order(ticker, TARGET_EXIT_PRICE, count=owned)
                    if new_id: state[ticker]["sell_order_id"] = new_id
            
            elif owned == 0 and total_committed > 0:
                # GHOST ORDER/OVERSELL PROTECTION: If we own NOTHING but have a resting sell
                logging.warning("⚠️ SAFETY ALERT: Owning 0 shares of %s but found %d shares for sale. Cancelling orders to prevent NO position.", ticker, total_committed)
                for s in sells:
                    cancel_order(str(s["order_id"]))

        return state

    except Exception as e:
        logging.error("Failed full audit: %s", e)
        return state


def monitor_active_positions(state: dict) -> dict:
    """Step 5: Check current prices for open positions and apply Stop Loss."""
    active_sells = {
        ticker: info
        for ticker, info in state.items()
        if info.get("status") == "pending_sell"
    }

    if not active_sells:
        return state

    for ticker, info in active_sells.items():
        try:
            # Fetch current market data
            data = kalshi_get(f"/trade-api/v2/markets/{ticker}")
            market = data.get("market", {})
            yes_bid = market.get("yes_bid")
            
            should_exit = False
            exit_reason = ""
            
            # 1. Normalize yes_bid (Handle Kalshi's cent/dollar inconsistency)
            if yes_bid is None and market.get("yes_bid_dollars") is not None:
                yes_bid = int(float(market["yes_bid_dollars"]) * 100)

            # 2. Robust Bid Policy: Prevent 1c panic exits if bid disappears for a split second.
            if yes_bid is None:
                empty_count = info.get("empty_bid_count", 0) + 1
                state[ticker]["empty_bid_count"] = empty_count
                if empty_count >= 5: # Increased to 5 checks (50 mins) for more stability
                    should_exit = True
                    exit_reason = f"NO BID (Empty Book - 5 consecutive checks)"
                else:
                    logging.info("Ticker %s has empty bid (count %d). Waiting for buffer...", ticker, empty_count)
            else:
                # Good bid found — reset panic buffer
                state[ticker]["empty_bid_count"] = 0
                # ONLY exit if price is strictly BELOW 30 cents
                if yes_bid < STOP_LOSS_PRICE:
                    should_exit = True
                    exit_reason = f"Price {yes_bid}¢ is below STOP LOSS threshold {STOP_LOSS_PRICE}¢"

            if should_exit:
                logging.warning("🛑 STOP LOSS TRIGGERED for %s: %s", ticker, exit_reason)
                
                # 1. Cancel existing take-profit order
                resting = get_portfolio_orders(ticker)
                for o in resting:
                    if o.get("action") == "sell": cancel_order(str(o["order_id"]))
                
                # 2. Place Emergency Market Exit (V2.16: Take whatever bid is there, min 1c)
                shares = info.get("shares", 7) # use state or default to 7
                exit_price = max(1, yes_bid or 1)
                exit_id = place_sell_order(ticker, exit_price, count=shares, is_emergency=True)
                if exit_id:
                    state[ticker]["status"] = "exited_stop_loss"
                    logging.info("EMERGENCY EXIT PLACED: %s at %d¢", ticker, exit_price)
                    
        except Exception as exc:
            logging.error("Failed to monitor position for %s: %s", ticker, exc)

    return state


# ---------------------------------------------------------------------------
# Timer Trigger (every 30 minutes)
# ---------------------------------------------------------------------------

@app.timer_trigger(
    schedule="0 */10 * * * *",
    arg_name="timer",
    run_on_startup=False,
)
def tennis_bot(timer: func.TimerRequest) -> None:
    """Main entry point — runs every 30 minutes."""
    logging.info("=" * 60)
    logging.info("TENNIS BOT RUN STARTED at %s", datetime.now(timezone.utc).isoformat())
    logging.info("=" * 60)

    # V2.15: Singleton Lock (Prevent Overlapping Runs)
    lock_blob_name = "bot_run.lock"
    container_client = ContainerClient.from_connection_string(
        os.environ["AZURE_STORAGE_CONNECTION_STRING"], 
        container_name=BLOB_CONTAINER
    )
    lock_client = container_client.get_blob_client(lock_blob_name)
    
    try:
        if lock_client.exists():
            props = lock_client.get_blob_properties()
            last_modified = props.last_modified
            # If the lock is less than 5 minutes old, assume another run is active
            if (datetime.now(timezone.utc) - last_modified).total_seconds() < 300:
                logging.warning("⚠️ CONCURRENCY GUARD: Another bot run is already in progress (started %s). Exiting.", last_modified)
                return
        
        # Create/Update lock
        lock_client.upload_blob(json.dumps({"start_time": datetime.now(timezone.utc).isoformat()}), overwrite=True)
    except Exception as e:
        logging.error("Failed to manage run lock: %s", e)

    if timer.past_due:
        logging.warning("Timer is past due — running anyway")

    try:
        # Load persisted state
        state = load_state()

        # Step 0: Sync actual portfolio to state (Proactive Discovery)
        state = sync_portfolio_to_state(state)

        # Step 1: Scan markets and place new buy orders
        state = scan_and_target(state)

        # Step 2: Check fills and place sell orders
        state = check_fills_and_sell(state)

        # Step 3: Auto-cleanup stale orders
        state = auto_cleanup(state)

        # Step 4: Clean up settled markets
        state = check_settled_markets(state)

        # Step 5: Monitor for Stop Loss (Drawdown Recovery)
        state = monitor_active_positions(state)

        # Persist updated state
        save_state(state)

        # Release lock
        try:
            lock_client.delete_blob()
        except:
            pass

        logging.info("TENNIS BOT RUN COMPLETED — %d tickers tracked", len(state))

    except Exception:
        logging.exception("TENNIS BOT RUN FAILED")
        raise
