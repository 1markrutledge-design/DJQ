import azure.functions as func

app = func.FunctionApp()

@app.timer_trigger(schedule="0 */10 * * * *", arg_name="myTimer", run_on_startup=True)
def test_timer(myTimer: func.TimerRequest) -> None:
    pass
